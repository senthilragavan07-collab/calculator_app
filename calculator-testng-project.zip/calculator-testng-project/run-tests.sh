#!/usr/bin/env bash
# Quick shell script to run tests
echo "Checking Maven and Java..."
mvn -version || { echo "Error: Maven is not installed"; exit 1; }
echo "Executing: mvn clean test"
mvn clean test
