# Java Maven TestNG Unit Testing Project

A simple Java Maven project demonstrating TestNG unit testing using `Calculator` and `CalculatorTest`.

## Project Structure

```text
calculator-testng-project/
├── pom.xml                               # Maven project definition and dependencies
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── example/
│   │               └── tests/
│   │                   └── Calculator.java      # Source class with add() and subtract()
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── example/
│       │           └── tests/
│       │               └── CalculatorTest.java  # TestNG test class with @BeforeMethod and @Test
│       └── resources/
│           └── testng.xml                       # TestNG XML suite configuration
└── README.md
```

## Quick Start Commands

```bash
# 1. Clean and compile
mvn clean compile

# 2. Run TestNG unit tests
mvn test

# 3. Run specific test class
mvn test -Dtest=CalculatorTest
```
