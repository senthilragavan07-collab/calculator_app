package com.example.tests;

/**
 * Simple Calculator class providing basic arithmetic operations.
 */
public class Calculator {

    /**
     * Adds two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the sum of a and b
     */
    public int add(int a, int b) {
        return a + b;
    }

    /**
     * Subtracts the second integer from the first integer.
     *
     * @param a the minuend
     * @param b the subtrahend
     * @return the difference between a and b
     */
    public int subtract(int a, int b) {
        return a - b;
    }
}