package com.example.tests;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Unit tests for Calculator using the TestNG testing framework.
 */
public class CalculatorTest {

    private Calculator calculator;

    /**
     * Pre-condition method executed before each @Test method.
     * Ensures an isolated, fresh Calculator instance is ready for testing.
     */
    @BeforeMethod
    public void setUp() {
        calculator = new Calculator();
    }

    /**
     * Tests the add method with inputs 5 and 3, asserting the result is 8.
     */
    @Test
    public void testAdd() {
        int result = calculator.add(5, 3);
        Assert.assertEquals(result, 8, "Assertion Failed: Addition of 5 and 3 should equal 8");
    }

    /**
     * Tests the subtract method with inputs 5 and 3, asserting the result is 2.
     */
    @Test
    public void testSubtract() {
        int result = calculator.subtract(5, 3);
        Assert.assertEquals(result, 2, "Assertion Failed: Subtraction of 5 and 3 should equal 2");
    }
}